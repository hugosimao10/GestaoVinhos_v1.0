create view CAIXASPORTIPODEVINHO as
(SELECT tipo_vinho, sum(qtd_caixas) as totalCaixas FROM PRODUTOFINAL 
GROUP BY tipo_vinho)
/

