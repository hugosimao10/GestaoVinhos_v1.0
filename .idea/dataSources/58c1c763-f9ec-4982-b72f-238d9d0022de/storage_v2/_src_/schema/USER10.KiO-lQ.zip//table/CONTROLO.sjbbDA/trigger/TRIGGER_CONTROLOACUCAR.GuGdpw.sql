create trigger TRIGGER_CONTROLOACUCAR
    before insert or update or delete
    on CONTROLO
    for each row
    when (NEW.qtd_acucar < 20)
BEGIN
:NEW.id_avaliacao :=null;
END;

/

