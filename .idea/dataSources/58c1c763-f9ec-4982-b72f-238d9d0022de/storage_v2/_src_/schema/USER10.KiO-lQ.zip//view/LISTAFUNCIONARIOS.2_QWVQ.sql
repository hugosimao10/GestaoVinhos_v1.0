create view LISTAFUNCIONARIOS as
(SELECT f.nome, f.tipo_funcionario, f.tlm FROM FUNCIONARIO f)
/

